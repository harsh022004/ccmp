import Navbar from "../components/Navbar";

const Product = () => {
  return (
    <>
      <Navbar />
      <h1>Hello World my Product </h1>
    </>
  );
};

export default Product;
